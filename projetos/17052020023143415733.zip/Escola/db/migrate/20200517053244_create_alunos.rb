class CreateAlunos < ActiveRecord::Migration[5.1]
  def change
    create_table :alunos do |t|
      t.string :Nome
      t.integer :Matricula
      t.float :Nota

      t.timestamps
    end
  end
end
