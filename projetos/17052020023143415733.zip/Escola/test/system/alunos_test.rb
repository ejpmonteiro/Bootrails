require "application_system_test_case"

class AlunosTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit alunos_url
  #
  #   assert_selector "h1", text: "Aluno"
  # end
end
